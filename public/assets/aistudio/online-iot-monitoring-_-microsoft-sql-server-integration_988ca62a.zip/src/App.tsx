/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Navbar, NavTab } from './components/Navbar';
import { LiveMonitoringView } from './components/LiveMonitoringView';
import { DeviceTopologyView } from './components/DeviceTopologyView';
import { ActuatorControlView } from './components/ActuatorControlView';
import { AlertsAndLogsView } from './components/AlertsAndLogsView';
import { MssqlStudioView } from './components/MssqlStudioView';
import { MssqlDocumentationView } from './components/MssqlDocumentationView';

import { 
  Device, 
  TelemetryReading, 
  Actuator, 
  AlertEvent, 
  MssqlConfig, 
  MssqlConnectionState 
} from './types/iot';

import { 
  initialDevices, 
  initialReadings, 
  initialActuators, 
  initialAlerts, 
  defaultMssqlConfig 
} from './data/mockDevices';

export default function App() {
  const [currentTab, setCurrentTab] = useState<NavTab>('monitoring');
  const [devices, setDevices] = useState<Device[]>(initialDevices);
  const [readings, setReadings] = useState<TelemetryReading[]>(initialReadings);
  const [actuators, setActuators] = useState<Actuator[]>(initialActuators);
  const [alerts, setAlerts] = useState<AlertEvent[]>(initialAlerts);
  const [telemetryLogs, setTelemetryLogs] = useState<TelemetryReading[]>(initialReadings);
  
  // Streaming Simulator
  const [isStreaming, setIsStreaming] = useState<boolean>(true);

  // Microsoft SQL Server state
  const [sqlConfig, setSqlConfig] = useState<MssqlConfig>(defaultMssqlConfig);
  const [sqlState, setSqlState] = useState<MssqlConnectionState>({
    status: 'simulated', // Starts in simulated sandbox mode for immediate interactive readiness
    serverVersion: 'Microsoft SQL Server 2022 / T-SQL Sandbox',
    currentDb: defaultMssqlConfig.database,
    latencyMs: 14,
    totalSyncedCount: 42,
    lastTestedAt: new Date().toISOString(),
  });
  
  const [isTestingConnection, setIsTestingConnection] = useState<boolean>(false);
  const [queuedForSql, setQueuedForSql] = useState<TelemetryReading[]>([]);
  const [isSyncingToSql, setIsSyncingToSql] = useState<boolean>(false);

  // Ref to track latest state inside interval
  const sqlConfigRef = useRef(sqlConfig);
  useEffect(() => {
    sqlConfigRef.current = sqlConfig;
  }, [sqlConfig]);

  const queuedRef = useRef(queuedForSql);
  useEffect(() => {
    queuedRef.current = queuedForSql;
  }, [queuedForSql]);

  // Batch sync handler to send buffered readings to SQL Server endpoint
  const performSqlSync = useCallback(async (itemsToSync: TelemetryReading[]) => {
    if (itemsToSync.length === 0) return;
    setIsSyncingToSql(true);

    try {
      const response = await fetch('/api/mssql/sync-telemetry', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ readings: itemsToSync }),
      });

      if (response.ok) {
        setSqlState(prev => ({
          ...prev,
          totalSyncedCount: prev.totalSyncedCount + itemsToSync.length,
          lastSyncTimestamp: new Date().toISOString(),
        }));
        // Remove synced items from queue
        setQueuedForSql(prev => prev.slice(itemsToSync.length));
      }
    } catch (err) {
      console.warn('Sync to SQL endpoint failed, will retry:', err);
    } finally {
      setIsSyncingToSql(false);
    }
  }, []);

  // Periodic Telemetry Simulator Engine
  useEffect(() => {
    if (!isStreaming) return;

    const interval = setInterval(() => {
      setReadings(prevReadings => {
        const updated = prevReadings.map(r => {
          // Subtle natural fluctuation
          let delta = 0;
          if (r.unit === '°C') delta = (Math.random() - 0.48) * 0.35;
          else if (r.unit === 'bar') delta = (Math.random() - 0.49) * 0.05;
          else if (r.unit === 'V') delta = (Math.random() - 0.5) * 0.4;
          else if (r.unit === 'kW') delta = (Math.random() - 0.5) * 1.8;
          else if (r.unit === 'm³/h') delta = (Math.random() - 0.48) * 0.5;
          else if (r.unit === 'pH') delta = (Math.random() - 0.5) * 0.02;
          else if (r.unit === 'ppm') delta = (Math.random() - 0.48) * 4;
          else if (r.unit === 'mm/s') delta = (Math.random() - 0.45) * 0.08;
          else delta = (Math.random() - 0.5) * 0.1;

          let newVal = +(r.value + delta).toFixed(r.unit === 'ppm' ? 0 : 2);
          
          // Determine status based on thresholds
          let status = r.status;
          if (newVal >= r.maxCritical || newVal <= r.minCritical) {
            status = 'critical';
          } else if (newVal >= r.maxWarning || newVal <= r.minWarning) {
            status = 'warning';
          } else {
            status = 'normal';
          }

          // If transition to critical/warning, create alert event
          if (status !== 'normal' && r.status === 'normal') {
            const newAlert: AlertEvent = {
              id: `ALT-${Date.now()}`,
              deviceId: r.deviceId,
              deviceName: r.deviceName,
              parameter: r.parameter,
              triggerValue: newVal,
              thresholdValue: r.maxWarning,
              unit: r.unit,
              severity: status as any,
              message: `${r.parameter} pada ${r.deviceName} (${newVal} ${r.unit}) melampaui batas ambang operasi.`,
              timestamp: new Date().toISOString(),
              isAcknowledged: false,
              isResolved: false,
            };
            setAlerts(prev => [newAlert, ...prev].slice(0, 50));
          }

          const newHistory = [...r.history.slice(1), newVal];

          return {
            ...r,
            value: newVal,
            status,
            timestamp: new Date().toISOString(),
            history: newHistory,
          };
        });

        // Add to historical logs
        setTelemetryLogs(prev => [...updated.slice(0, 3), ...prev].slice(0, 300));

        // Buffer for MSSQL sync
        setQueuedForSql(prev => [...prev, ...updated.slice(0, 3)].slice(0, 200));

        return updated;
      });
    }, 2800);

    return () => clearInterval(interval);
  }, [isStreaming]);

  // Auto-sync periodic timer if enabled in config
  useEffect(() => {
    if (!sqlConfig.autoSync) return;

    const syncIntervalMs = (sqlConfig.syncIntervalSec || 5) * 1000;
    const syncTimer = setInterval(() => {
      if (queuedRef.current.length > 0) {
        performSqlSync(queuedRef.current.slice(0, 20));
      }
    }, syncIntervalMs);

    return () => clearInterval(syncTimer);
  }, [sqlConfig.autoSync, sqlConfig.syncIntervalSec, performSqlSync]);

  // Anomaly trigger handler (simulates a sudden spike to test alarms and SQL write)
  const handleTriggerAnomaly = useCallback((readingId: string) => {
    setReadings(prev => prev.map(r => {
      if (r.id !== readingId) return r;

      const spikedValue = +(r.maxWarning + (r.maxCritical - r.maxWarning) * 0.75).toFixed(2);
      const newAlert: AlertEvent = {
        id: `ALT-${Date.now()}`,
        deviceId: r.deviceId,
        deviceName: r.deviceName,
        parameter: r.parameter,
        triggerValue: spikedValue,
        thresholdValue: r.maxWarning,
        unit: r.unit,
        severity: 'warning',
        message: `Simulasi lonjakan anomali: ${r.parameter} melonjak tajam ke ${spikedValue} ${r.unit}. Sistem keselamatan memicu notifikasi.`,
        timestamp: new Date().toISOString(),
        isAcknowledged: false,
        isResolved: false,
      };

      setAlerts(a => [newAlert, ...a]);

      const updatedReading: TelemetryReading = {
        ...r,
        value: spikedValue,
        status: 'warning',
        timestamp: new Date().toISOString(),
        history: [...r.history.slice(1), spikedValue],
      };

      // Push to telemetry log and sync queue
      setTelemetryLogs(logs => [updatedReading, ...logs].slice(0, 300));
      setQueuedForSql(q => [updatedReading, ...q]);

      return updatedReading;
    }));
  }, []);

  // Custom reading injection handler
  const handleInjectCustomReading = useCallback((payload: {
    deviceId: string;
    parameter: string;
    value: number;
    unit: string;
  }) => {
    const targetDev = devices.find(d => d.id === payload.deviceId);
    const readingItem: TelemetryReading = {
      id: `TEL-INJ-${Date.now()}`,
      deviceId: payload.deviceId,
      deviceName: targetDev?.name || payload.deviceId,
      location: targetDev?.location || 'Process Plant',
      parameter: payload.parameter,
      value: payload.value,
      unit: payload.unit,
      status: payload.value > 100 ? 'warning' : 'normal',
      timestamp: new Date().toISOString(),
      minWarning: 0,
      maxWarning: 90,
      minCritical: 0,
      maxCritical: 110,
      history: [payload.value, payload.value, payload.value],
    };

    setReadings(prev => [readingItem, ...prev]);
    setTelemetryLogs(prev => [readingItem, ...prev]);
    setQueuedForSql(prev => [readingItem, ...prev]);
  }, [devices]);

  // Actuator update
  const handleUpdateActuator = useCallback((id: string, newState: boolean | number, user: string) => {
    setActuators(prev => prev.map(a => {
      if (a.id !== id) return a;
      return {
        ...a,
        state: newState,
        lastUpdated: new Date().toISOString(),
        lastUser: user,
      };
    }));
  }, []);

  // Alert acknowledge
  const handleAcknowledgeAlert = useCallback((id: string, user: string) => {
    setAlerts(prev => prev.map(a => {
      if (a.id !== id) return a;
      return {
        ...a,
        isAcknowledged: true,
        acknowledgedBy: user,
        acknowledgedAt: new Date().toISOString(),
      };
    }));
  }, []);

  // Alert resolve
  const handleResolveAlert = useCallback((id: string) => {
    setAlerts(prev => prev.map(a => {
      if (a.id !== id) return a;
      return {
        ...a,
        isResolved: true,
        resolvedAt: new Date().toISOString(),
      };
    }));
  }, []);

  // Test real MSSQL Connection via server.ts backend
  const handleTestMssqlConnection = async () => {
    setIsTestingConnection(true);
    setSqlState(prev => ({ ...prev, status: 'connecting' }));

    try {
      const response = await fetch('/api/mssql/test-connection', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(sqlConfig),
      });

      const data = await response.json();

      if (data.success && data.connected) {
        setSqlState({
          status: 'connected',
          latencyMs: data.latencyMs,
          serverVersion: data.serverVersion,
          currentDb: data.currentDb,
          serverTime: data.serverTime,
          lastTestedAt: new Date().toISOString(),
          totalSyncedCount: sqlState.totalSyncedCount,
        });
      } else {
        // If external network is unreachable or port is blocked in cloud sandbox,
        // present exact diagnostic and keep sandbox simulation active so user is not blocked
        setSqlState({
          status: 'error',
          latencyMs: data.latencyMs || 84,
          errorCode: data.errorCode || 'ESOCKET',
          errorMessage: data.message || 'Koneksi ke Microsoft SQL Server gagal atau timeout.',
          diagnostic: data.diagnostic,
          lastTestedAt: new Date().toISOString(),
          totalSyncedCount: sqlState.totalSyncedCount,
        });
      }
    } catch (err: any) {
      setSqlState({
        status: 'error',
        errorMessage: err.message || 'Gagal menghubungi server proxy backend',
        diagnostic: 'Periksa apakah port 3000 backend aktif.',
        lastTestedAt: new Date().toISOString(),
        totalSyncedCount: sqlState.totalSyncedCount,
      });
    } finally {
      setIsTestingConnection(false);
    }
  };

  const handleManualSqlSync = () => {
    if (queuedForSql.length > 0) {
      performSqlSync(queuedForSql);
    } else {
      // Sync latest readings
      performSqlSync(readings.slice(0, 10));
    }
  };

  return (
    <div className="min-h-screen bg-[#0b0f17] text-slate-100 flex flex-col selection:bg-emerald-500/30 selection:text-emerald-300">
      
      {/* Strict 3-zone Header */}
      <Navbar
        currentTab={currentTab}
        onTabChange={setCurrentTab}
        isStreaming={isStreaming}
        onToggleStreaming={() => setIsStreaming(!isStreaming)}
        sqlState={sqlState}
        onOpenSqlStudio={() => setCurrentTab('mssql-studio')}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {currentTab === 'monitoring' && (
          <LiveMonitoringView
            devices={devices}
            readings={readings}
            onTriggerAnomaly={handleTriggerAnomaly}
            onInjectCustomReading={handleInjectCustomReading}
            sqlState={sqlState}
            onNavigateToSql={() => setCurrentTab('mssql-studio')}
            onNavigateToDocs={() => setCurrentTab('mssql-docs')}
            queuedForSqlCount={queuedForSql.length}
            onManualSqlSync={handleManualSqlSync}
            isSyncingToSql={isSyncingToSql}
          />
        )}

        {currentTab === 'topology' && (
          <DeviceTopologyView
            devices={devices}
            readings={readings}
          />
        )}

        {currentTab === 'actuators' && (
          <ActuatorControlView
            actuators={actuators}
            onUpdateActuator={handleUpdateActuator}
          />
        )}

        {currentTab === 'alerts' && (
          <AlertsAndLogsView
            alerts={alerts}
            readings={readings}
            onAcknowledgeAlert={handleAcknowledgeAlert}
            onResolveAlert={handleResolveAlert}
            telemetryLogs={telemetryLogs}
          />
        )}

        {currentTab === 'mssql-studio' && (
          <MssqlStudioView
            config={sqlConfig}
            onUpdateConfig={setSqlConfig}
            connectionState={sqlState}
            onTestConnection={handleTestMssqlConnection}
            isTesting={isTestingConnection}
            onManualSync={handleManualSqlSync}
            isSyncing={isSyncingToSql}
            queuedCount={queuedForSql.length}
          />
        )}

        {currentTab === 'mssql-docs' && (
          <MssqlDocumentationView />
        )}
      </main>

      {/* Quiet Anti-Slop Footer */}
      <footer className="border-t border-slate-800/80 bg-[#090d14] px-4 py-6 text-xs text-slate-500 mt-auto">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-300">NexusIoT Platform</span>
            <span>·</span>
            <span>Industrial Monitoring &amp; Microsoft SQL Server Integration</span>
          </div>

          <div className="flex items-center gap-4 text-slate-400">
            <button 
              onClick={() => setCurrentTab('mssql-docs')}
              className="hover:text-slate-200 transition-colors"
            >
              Dokumentasi T-SQL
            </button>
            <span>·</span>
            <button 
              onClick={() => setCurrentTab('mssql-studio')}
              className="hover:text-slate-200 transition-colors"
            >
              SQL Studio
            </button>
            <span>·</span>
            <span className="font-mono text-slate-500">T-SQL 1433 TCP</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
